#include <unistd.h>

int	my_putchar(const char c)
{
  return (write(1, &c, 1));
}

int	my_fputchar(const int fd, const char c)
{
  return (write(fd, &c, 1));
}
