#include "utils.h"
#include <stdlib.h>

char	*my_strdup(const char *src)
{
  char	*new;

  if (!(new = fmalloc(sizeof(char) * (my_strlen(src) + 1))))
    return (NULL);
  my_strcpy(new, src);
  return (new);
}
