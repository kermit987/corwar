#include "utils.h"
#include <unistd.h>

int	my_puterror(const char *str)
{
  if (str == NULL)
    return (0);
  return (write(2, str, my_strlen(str)));
}

int	my_putnerror(const char *str, const int n)
{
  if (str == NULL)
    return (0);
  return (write(2, str, n));
}
