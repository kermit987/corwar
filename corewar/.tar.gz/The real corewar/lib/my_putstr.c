#include "utils.h"
#include <unistd.h>

int	my_putnstr(const char *str, const int n)
{
  if (str == NULL)
    return (0);
  return (write(1, str, n));
}

int	my_putstr(const char *str)
{
  if (str == NULL)
    return (0);
  return (write(1, str, my_strlen(str)));
}

int	my_fputstr(const int fd, const char *str)
{
  if (str == NULL)
    return (0);
  return (write(fd, str, my_strlen(str)));
}

int	my_fputnstr(const int fd, const char *str, const int n)
{
  if (str == NULL)
    return (0);
  return (write(fd, str, n));
}
