#include <stdlib.h>

unsigned int	my_strlen(const char *str)
{
  if (str == NULL || str[0] == '\0')
    return (0);
  return (my_strlen(str + 1) + 1);
}
