#include "utils.h"

int	my_putnbr(int nb)
{
  int	ret;

  ret = 0;
  if (nb == -2147483648)
    return (my_putstr("-2147483648"));
  if (nb < 0)
    {
      nb = -nb;
      ret += my_putchar('-');
    }
  if (nb >= 10)
    return (my_putnbr(nb / 10) + ret);
  return (my_putchar((nb % 10) + '0'));
}

int	my_fputnbr(const int fd, int nb)
{
  int	ret;

  ret = 0;
  if (nb == -2147483648)
    return (my_fputstr(fd, "-2147483648"));
  if (nb < 0)
    {
      nb = -nb;
      ret += my_fputchar('-', fd);
    }
  if (nb >= 10)
    return (my_fputnbr(nb / 10, fd) + ret);
  return (my_fputchar((nb % 10) + '0', fd));
}
