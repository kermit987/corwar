#include "my_fprintf.h"

int	call_fct_specified(const int fd, t_specifier *specifier,
			   const char *format, va_list arg_list)
{
  short	i;

  i = 0;
  while (specifier[i].specifier)
    {
      if (specifier[i].specifier == *format)
	return (specifier[i].fct_ptr(fd, arg_list));
      i = i + 1;
    }
  return (display_it(fd, format - 1));
}
