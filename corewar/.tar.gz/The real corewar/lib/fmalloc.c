#include "utils.h"
#include <stdlib.h>

void	*fmalloc(int bytes)
{
  void	*tmp;

  if (!(tmp = malloc(bytes)))
    (void)my_puterror("could not alloc\n");
  return (tmp);
}
