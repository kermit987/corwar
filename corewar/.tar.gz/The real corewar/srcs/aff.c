/*
** aff.c for  in /home/karmes_l/Projets/Prog_Elem/Corewar/CPE_2014_corewar/corewar/srcs
** 
** Made by lionel karmes
** Login   <karmes_l@epitech.net>
** 
** Started on  Tue Apr  7 16:21:00 2015 lionel karmes
** Last update Wed Apr  8 14:19:59 2015 lionel karmes
*/

#define OCTET_AFF (5)

int	valid_reg(char map[MAP_SIZE], int offset)
{
  num_reg = get_nb(map, offset, 1);
  if (num_reg <= 0 || num_reg > 16)
    return (0);
  return (nb);
}

short	aff(t_champ *champ, char map[MAP_SIZE], int offset, unsigned int cycle)
{
  int	num_reg;

  champ->next = op_tab[15].nbr_cycles;
  if (op_tab[15].nbr_cycles > cycle)
    return (0);
  if (what_type(0, map[offset]) != T_REG) /* l'octet de paramétrage n'est pas bon */
    return (0);
  if ((num_reg = valid_reg(map, offset + 1)) == 0)
    return (0);
  my_putchar(champ->registres[num_reg - 1]);
  return (OCTET_AFF); /* 1 + 4 */
}
