/*
** corewar.c for corewar in /home/metz_a/brouillons/corewar
** 
** Made by Aurélien Metz
** Login   <metz_a@epitech.net>
** 
** Started on  Thu Apr  9 12:37:49 2015 Aurélien Metz
** Last update Fri Apr 10 12:07:52 2015 Aurélien Metz
*/

#include "corewar.h"

int		main(int ac, char **av)
{
  t_champ	champions[NBR_CHAMP];
  char		map[MAP_SIZE];
  int		dump;

  if (!(dump = initialisement(champions, map, ac, av + 1)))
    return (-1);
  game(champions, map, dump);
  return (0);
}
