/*
** aff.c for  in /home/karmes_l/Projets/Prog_Elem/Corewar/CPE_2014_corewar/corewar/srcs
** 
** Made by lionel karmes
** Login   <karmes_l@epitech.net>
** 
** Started on  Tue Apr  7 16:21:00 2015 lionel karmes
** Last update Fri Apr 10 19:30:02 2015 Aurélien Metz
*/

int		args_valid(char code, char o_param)
{
  args_type_t	type;

  while (i < op_tab[code - 1].nbr_args)
    {
      type = type(i, o_param);
      if (op_tab[code - 1].type[i] & type != type) /* Mauvais o_param */
	return (0);
      ++i;
    }
  return (1);
}

int		get_type(args_type_t type)
{
  if (type == INDX_SIZE || type == DIRX_SIZE) /* car les index \
						 sont sur 2 octets */
    return (2);
  return (type);
}

/* ne marche pas pour live */
/* ne marchera pas pour lld, lldi, lfork car il n'y a \
   pas de % IDX_MOD pour eux */
/* PS : j'ai pris IND_SIZE pour indirect_size et IDX_SIZE pour\
   index_size_indirect */
/* DIR_SIZE pour direct_size et DIRX_SIZE pour un index_size_direct */

int	get_nb2(t_champ *champ, char map[MAP_SIZE],
		int offset, args_type_t *type)
{
  int	num;

  if (type == 1) /* registre */
    {
      if ((num = valid_reg(map, offset)) == 0)
	*type = 0;
      else
	return (champ->registres[num]);
    }
  else if (type == DIR_SIZE)
    return (get_nb(map, offset, DIR_SIZE));
  else if (type == DIRX_SIZE) /* index direct */
    return (get_nb(map, offset, 2));
  else
    {
      num = (champion->pc + (get_nb(map, offset, IND_SIZE) % IDX_MOD)) % MAP_SIZE;
      return (get_nb(map, map[num], (type == IND_SIZE) ? REG_SIZE : 2));
    }
  return (0);
}

int	get_nb3(t_champ *champ, char map[MAP_SIZE],
			int offset, args_type_t *type)
{
  int	num;

  if (type == 1) /* registre */
    {
      if ((num = valid_reg(map, offset)) == 0)
	*type = 0;
      else
	return (champ->registres[num_reg]);
    }
  if (type == DIR_SIZE)
    return (get_nb(map, offset, DIR_SIZE));
  if (type == DIRX_SIZE) /* index direct */
    return (get_nb(map, offset, 2));
  else
    {
      num = (champion->pc + (get_nb(map, offset, IND_SIZE))) % MAP_SIZE;
      return (get_nb(map, map[num], (type == IND_SIZE) ? REG_SIZE : 2));
    }
  return (0);
}

short		sti(t_champ *champ, char map[MAP_SIZE],
		    int offset, unsigned int cycle)
{
  int		nb_octet;
  int		i;
  int		tab[3];

  nb_octet = 0;
  champ->next = op_tab[10].nbr_cycles;
  champ->flag = 1;
  if (op_tab[10].nbr_cycles > cycle)
    return (0);
  if (args_valid(11, map[offset]) == 0)
    return (0);
  i = 0;
  while (i < op_tab[10].nbr_args)
    {
      type = type(i, map[offset]);
      type = argc_define_octal(10, type, i);
      nb_octet += get_type(type);
      tab[i++] = get_nb2(champ, map, offset + nb_octet, champion->type);
      if (type == 0)
	return (0);
    }
  map[(tab[1] + tab[2]) % MEM_SIZE] = tab[0];
  return (nb_octet);
}
