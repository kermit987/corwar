/*
** load_champions.c for corewar in /home/metz_a/brouillons/corewar
** 
** Made by Aurélien Metz
** Login   <metz_a@epitech.net>
** 
** Started on  Thu Apr  9 17:02:55 2015 Aurélien Metz
** Last update Fri Apr 10 14:17:22 2015 Aurélien Metz
*/

#include "load_champions.h"

int	load_champion(t_champ *champion, int fd, char map[MAP_SIZE])
{
  if (!champion->addr)
    champion->addr = blp(map);
  if (champion->header.prog_size > MAP_SIZE
      || check_overlap(champion, map))
    return (my_fprintf(ERROUT, OVERLAP));
  if (get_loaded(champion, fd, map)
      || !(champion->proc = fmalloc(sizeof(t_process))))
    return (-1);
  champion->proc_nbr = 1;
  champion->proc[0].pc = champion->addr;
  champion->proc[1].pc = 0;
  return (0);
}

static int	is_blp(t_blp *line, char map[MAP_SIZE])
{
  int	i;
  int	n;

  n = 0;
  i = line->pos;
  if (line->len > MAP_SIZE)
    return (0);
  while (n < line->len)
    {
      if (map[i++ % MAP_SIZE])
	return (0);
      n++;
    }
  return (1);
}

static unsigned int	blp(char map[MAP_SIZE])
{
  t_blp		blp;
  t_blp		line;

  blp.pos = 0;
  blp.len = 1;
  line.pos = 0;
  line.len = 1;
  while ((blp.pos + blp.len) < MAP_SIZE)
    {
      while (is_blp(&line, map))
	line.len += 1;
      line.len -= line.len > 1 ? 1 : 0;
      if (line.len > blp.len)
	{
	  blp.pos = line.pos;
	  blp.len = line.len;
	}
      if (blp.len == MAP_SIZE)
	return (blp.pos + (blp.len / 2));
      line.pos++;
    }
  return (blp.pos + (blp.len / 2));
}

static int	check_overlap(t_champ *champion, char map[MAP_SIZE])
{
  unsigned int	i;
  int		sub_addr;

  i = 0;
  sub_addr = champion->addr;
  while (i < champion->header.prog_size)
    {
      if (map[sub_addr++ % MAP_SIZE] != 0)
	return (1);
      i++;
    }
  return (0);
}

int		get_loaded(t_champ *champion, int fd, char map[MAP_SIZE])
{
  unsigned int	i;
  char		early_file[SIZE_FOR_INSTRUCTIONS + 1];

  i = 0;
  if (xread(fd, early_file, SIZE_FOR_INSTRUCTIONS) == -1)
    return (1);
  while (i < champion->header.prog_size)
    {
      if (xread(fd, map + champion->addr, 1) == -1)
	return (-1);
      if (champion->addr == MAP_SIZE - 1)
	champion->addr = 0;
      champion->addr++;
      i++;
    }
  close(fd);
  return (0);
}
