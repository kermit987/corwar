/*
** instruction3.c for corewar in /home/metz_a/brouillons/corewar
** 
** Made by Aurélien Metz
** Login   <metz_a@epitech.net>
** 
** Started on  Fri Apr 10 16:12:13 2015 Aurélien Metz
** Last update Fri Apr 10 20:31:40 2015 Aurélien Metz
*/

#include "instruction.h"


int	my_fork(t_champ *champion, char map[MAP_SIZE],
		t_process *proc, unsigned int cycle)
{
  proc->cd = 800;
  if (op_tab[11].nbr_cycles > (int)cycle
      || find_type(0, map[proc->pc + 1] != T_DIR))
    return (1);
  if (!(champion->proc =
	realloc(champion->proc,	sizeof(t_process)
		* (champion->proc_nbr + 1))))
    {
      my_fprintf(ERROUT, REALLOC, champion->id, champion->header.prog_name);
      champion->id = 0;
    }
  champion->proc_nbr += 1;
  champion->proc[champion->proc_nbr].pc = proc->pc
    + (get_nb(map, proc->pc + 1, 2) % IDX_MOD);
  champion->proc[champion->proc_nbr].cd = 0;
  return (0);
}

int	aff(t_champ *champion, char map[MAP_SIZE],
	    t_process *proc, unsigned int cycle)
{
  int	num_reg;

  proc->cd = op_tab[15].nbr_cycles;
  if (op_tab[15].nbr_cycles > (int)cycle)
    return (1);
  if (find_type(0, map[proc->pc + 1]) != T_REG)
    return (1);
  if ((num_reg = valid_reg(map, proc->pc + 1 + 1)) == 0)
    return (1);
  my_putchar(champion->regs[num_reg - 1]);
  return (OCTET_AFF);
}

int		and(t_champ *champion, char map[MAP_SIZE],
		    t_process *proc, unsigned int cycle)
{
  return (1);
  (void)champion;
  (void)map;
  (void)proc;
  (void)cycle;
}

short		sti(t_champ *champion, char map[MAP_SIZE],
		    t_process *proc, unsigned int cycle)
{
  int		nb_octet;
  int		i;
  int		tab[3];

  nb_octet = 0;
  proc->cd = op_tab[10].nbr_cycles;
  champion->carry = 1;
  if (op_tab[10].nbr_cycles > (int)cycle)
    return (0);
  if (args_valid(11, map[proc->pc]) == 0)
    return (0);
  i = 0;
  while (i < op_tab[10].nbr_args)
    {
      champion->type = find_type(i, map[proc->pc]);
      champion->type = argc_define_octal(10, champion->type, i);
      nb_octet += get_type(champion->type);
      tab[i++] = get_nb2(champion, map, proc->pc + nb_octet, proc);
      if (champion->type == 0)
	return (0);
    }
  map[(tab[1] + tab[2]) % MEM_SIZE] = tab[0];
  return (nb_octet);
}
